var map = L.map('map').setView([4.874186, -74.146562], 13);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

var marker = L.marker([4.872183933899855, -74.14456801294413]).addTo(map);
var marker = L.marker([4.872035717488616, -74.1450653393937]).addTo(map);
